#pragma once
#include<string>
#include "MainMenu.h"
#include "PotionRecipe.h"
#include<vector>

class AlchemyWorkshop
{
public:


	MainMenu* mainmenu = nullptr;

	bool isShowworkshop = true;

	std::vector<PotionRecipe>vpotionrecipes;


	void SetMainMenu(MainMenu* menu);


	void AlchemyWorkshopSystem();
	

	void AddPotionRecipe(const PotionRecipe& addrecipe);


	void ShowAllRecipes();


	void SearchByName(std::string name);


	void SearchByIngredient(std::string ingredient);

};
