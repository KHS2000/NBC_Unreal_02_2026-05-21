#include<iostream>
#include"Archer.h"

using namespace std;

Archer::Archer(string name, int hp, int mp, int power, int defence)
		: Player(name, hp, mp, power, defence)
	{
		this->defence += 30;
		job = "�ü�";
		this->power = power;
	}

//void Archer::attack(Monster& monster)
//	{
//	
//	}


int Archer::AttackDamage(Monster* &monster)
{
	
	int Damage=0;
	Damage = (power - monster->GetDefence())/3;

	if (Damage <= 0)
	{
		Damage = 1;
	}

	int archerdamage = Damage * 3;

	this->damage = Damage;

	return archerdamage;
}

void Archer::Attack(Monster* &monster)
{
	int monstercurrentHP;
	monstercurrentHP = monster->GetHp();//�� ü��
	int Damage = 0;
	Damage = (power - monster->GetDefence()) / 3;

	if (Damage <= 0)
	{
		Damage = 1;
	}

	int archerdamage = Damage * 3;

	this->damage = Damage;
	cout << "-------- �÷��̾� �� --------\n";

	cout << "[" << job << "] " << "������ ȭ���� ���!\n ";
	cout<< monster->GetName() << "���� " << damage << "������! (x3)\n";
	monster->SetHp(monster->GetHp() - archerdamage);
	cout << "������HP: " << monstercurrentHP << " -> " << monster->GetHp();
}