#pragma once
#include "string"
#include "Player.h"

class Archer :public Player
{
public:
	Archer(std::string name, int hp, int mp, int power, int defence);

	int power;

	int damage;

	int archerdamage;

	//void attack(Monster& monster) override;

	int AttackDamage(Monster* &monster) override;

	void Attack(Monster* &monster) override;
};