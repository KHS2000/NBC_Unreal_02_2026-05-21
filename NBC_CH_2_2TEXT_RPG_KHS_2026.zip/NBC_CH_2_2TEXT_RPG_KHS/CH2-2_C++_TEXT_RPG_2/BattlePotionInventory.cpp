#include<iostream>
#include "BattlePotionInventory.h"

using namespace std;



void BattlePotionInventory::bp::healplayerhp(Player* player)
{
	int playercurrenthp = player->getHP();
	player->setHP(min(player->getHP() + healpoint, player->getMaxhp()));
	cout<<"\n\n" << name << " ���� ���! " << name << healpoint << " ȸ�� (" << playercurrenthp << " -> " << player->getHP() << ")";
}

void BattlePotionInventory::bp::healplayermp(Player* player)
{
	int playercurrentmp = player->getMP();
	player->setMP(min(player->getMP() + healpoint, player->getMaxmp()));
	cout << name << " ���� ���! " << name << healpoint << " ȸ�� (" << playercurrentmp << " -> " << player->getHP() << ")";
}


void BattlePotionInventory::addpotion(bp& potion)
{
	bpinventory.push_back(potion);
}

void BattlePotionInventory::spawnpotion()
{
	bp hppotion = { "HP",50,50 }; //���� �� HP���� ����ü
	bp hppotion2 = { "HP",50,50 }; //���� �� HP���� ����ü
	bp mppotion = { "MP",50,50 }; //���� �� MP���� ����ü

	bpinventory.push_back(hppotion);
	bpinventory.push_back(hppotion2);
	bpinventory.push_back(mppotion);
}

void BattlePotionInventory::ShowBattleInventory(Player* player)
{
	

	while (isshow)
	{
		int choice = 0;
		cout << "\n--------[ �κ��丮 ]--------\n";

		int countNumber = 1;
		for (const auto& n : bpinventory)
		{
			cout << countNumber << ". " << n.name << "���� (" << n.price << "G)\n";
			cout << "----------------------------\n";
			++countNumber;
		}
		cout << "0. ���ư���\n";
		cout << "----------------------------\n";
		

		cout << "����� �������� �����ϼ���: ";
		cin >> choice;
		cout << "\n\n";
		switch (choice)
		{
		case 1:
		{
			if(bpinventory.size()==0)
			{
				break;
			}
			bpinventory[0].healplayerhp(player);
			bpinventory.erase(bpinventory.begin() + 0);
			break;
		}
		case 2:
		{
			if (bpinventory.size() <= 1)
			{
				break;
			}
			bpinventory[1].healplayermp(player);
			bpinventory.erase(bpinventory.begin() + 1);
			break;
		}
		case 0:
		{
			cout << "\n\n\n";
			return;
			break;
		}

		}
	}
}
