#pragma once
#include<string>
#include<vector>
#include<algorithm>
#include "Player.h"

class BattlePotionInventory
{
public:

	bool isshow = true;


	struct bp
	{
		std::string name;
		int price;
		int healpoint;
		int potioncount;

		void healplayerhp(Player* player);
		void healplayermp(Player* player);

	};

	std::vector<bp>bpinventory;


	void addpotion(bp& potion);


	void ShowBattleInventory(Player* player);

	void spawnpotion();



};
