#pragma once
#include<string>
#include "Player.h"
#include "InventorySystem.h"
#include "ChangeMenu.h"

class BattleSystem {
public:

	//Player* player;
	Player* &player;
	InventorySystem& myinventorysystem;
	Monster* currentMonster=nullptr;
	ChangeMenu& mychangemenu;

	int playerattackdamage = 0;
	int monsterattackdamage = 0;
	bool isPlayerlive = true;


	int monstercurrentHP = 0;
	int playercurrentHP = 0;

	~BattleSystem();


	BattleSystem(Player* &player, InventorySystem& myinventorysystem, ChangeMenu& mychangemenu);
	


	void BattleStart();
	
};