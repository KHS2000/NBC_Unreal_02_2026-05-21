#pragma once

class ChangeMenu {
public:
	bool ischangemenu=true;
};
