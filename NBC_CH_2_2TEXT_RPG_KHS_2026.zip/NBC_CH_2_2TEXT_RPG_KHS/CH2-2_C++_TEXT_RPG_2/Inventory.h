//#pragma once
//
//template<typename T>
//class Inventory
//{
//public:
//
//	T* pItems_;
//	int capacity_=10;
//	int size_=0;
//
//	Inventory()
//	{
//		pItems_ = new T[capacity_];
//	}
//
//	Inventory& operator=(const Inventory& other)
//	{
//		if (this == &other)
//		{
//			return *this;
//		}

	//	delete[] pItems_;

	//	this->capacity_ = other.capacity_;
	//	this->size_ = other.size_;

	//	pItems_ = new T[capacity_];

	//	for (int i = 0; i < size_; ++i)
	//	{
	//		pItems_[i] = other.pItems_[i];
	//	}

	//	return *this;
	//}


	//~Inventory()
	//{
	//	delete[] pItems_;
	//}
	//

	//void AddItem(T Itemt)
	//{
	//	int itemcount;

	//	if (size_>=capacity_)
	//	{
	//		cout << "�κ��丮�� ���� á���ϴ�!"<<endl;
	//		Resize(capacity_*2);
	//	}

	//	pItems_[size_] = Itemt;
	//	++size_;

	//}


	//void RemoveLastItem()
	//{
	//	--size_;
	//}


//	void PrintAllItems()
//	{
//		for (int i = 0; i < size_; ++i)
//		{
//			cout << i + 1 << ". " << pItems_[i].name << endl;
//		}
//	}
//
//	void Resize(int newCapacity)
//	{
//		if (newCapacity <= capacity_)
//		{
//			return;
//		}
//
//		capacity_ = newCapacity;
//		T* newpItems_ = new T[capacity_];
//
//		for (int i = 0; i < size_; i++)
//		{
//			newpItems_[i] = pItems_[i];
//		}
//
//		delete[] pItems_;
//
//		pItems_ = newpItems_;
//	}
//
//
//	int GetSize()
//	{
//		return size_;
//	}
//
//
//	int GetCapacity()
//	{
//		return capacity_;
//	}
//};
