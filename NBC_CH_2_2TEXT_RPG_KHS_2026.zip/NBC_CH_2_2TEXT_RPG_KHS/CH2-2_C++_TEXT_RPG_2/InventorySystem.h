#pragma once
#include<string>
#include "Item.h"
#include "vector"

class InventorySystem
{
public:
	std::vector<Item>Inventory;
	std::vector<Potion>battleInventory;

	const int Max_Inventory = 10;

	void AddItem(std::string& name, int price);

	//void AddPotion(std::string& name, int price);

	void ShowInventory();

	//void BattleInventory();

};