#include"Item.h"
#include<iostream>
#include<algorithm>

using namespace std;

void Item::PrintInfo()const
{
	cout << "�����۸�: " << name << "  (" << price << "G)" << endl;
}

void Potion::Recovery(Player* player)const
{
	player->setHP(min(player->getHP(), player->maxhp));
}

void Potion::PrintInfo()const
{
	cout  << name << "  (" << price << "G)" << endl;
}