#pragma once
#include<string>
#include<algorithm>
#include"Player.h"

struct Item
{
	std::string name;
	int price;

	void PrintInfo()const;
};

struct Potion
{
	std::string name;
	int price;
	void PrintInfo()const;
	void Recovery(Player* player)const;
};
