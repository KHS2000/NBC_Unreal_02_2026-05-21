#pragma once
#include<string>

class ItemT
{
public:
	std::string name;
	int price;
};
