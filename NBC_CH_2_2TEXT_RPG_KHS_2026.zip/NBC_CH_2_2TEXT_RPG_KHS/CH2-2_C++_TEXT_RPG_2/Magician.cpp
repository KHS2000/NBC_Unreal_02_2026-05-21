#include<iostream>
#include "Magician.h"

using namespace std;

Magician::Magician(string name, int hp, int mp, int power, int defence)
		: Player(name, hp, mp, power, defence)
	{
		job = "������";
		this->mp += 30;
		this->power = power;
	}




int Magician::AttackDamage(Monster* &monster)
{
	int Damage = 0;
	Damage = power - monster->GetDefence();


	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;

	return Damage;

}

void Magician::Attack(Monster*& monster)
{
	int monstercurrentHP;
	monstercurrentHP = monster->GetHp();//�� ü��
	int Damage = 0;
	Damage = power - monster->GetDefence();


	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;
	cout << "-------- �÷��̾� �� --------\n";

	cout << "[" << job << "] " << "���̾ �߻�!\n ";
	cout<< monster->GetName() << "���� " << damage << "������!\n";
	monster->SetHp(monster->GetHp() - damage);
	cout << "������HP: " << monstercurrentHP << " -> " << monster->GetHp();
}
