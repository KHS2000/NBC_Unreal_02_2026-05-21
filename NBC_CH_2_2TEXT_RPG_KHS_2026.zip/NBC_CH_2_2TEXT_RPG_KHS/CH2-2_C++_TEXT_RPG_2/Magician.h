#pragma once
#include "Player.h"
#include<string>

class Magician :public Player
{
public:
	Magician(std::string name, int hp, int mp, int power, int defence);

	int power=0;

	int damage=0;


	int AttackDamage(Monster* &monster) override;

	void Attack(Monster*& monster)override;

};



