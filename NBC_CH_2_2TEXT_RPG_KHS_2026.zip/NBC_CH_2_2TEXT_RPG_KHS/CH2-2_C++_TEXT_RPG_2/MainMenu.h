#pragma once
#include <string>

#include "InventorySystem.h"
#include "Player.h"
#include "BattleSystem.h"
#include "ChangeMenu.h"
#include "BattlePotionInventory.h"

class AlchemyWorkshop;

class MainMenu {
public:
	bool isMenu = true;

	InventorySystem& myinventorysystem;
	AlchemyWorkshop& myalchemyworkshop;
	Player* player;
	BattleSystem& mybattlesystem;
	ChangeMenu& mychangemenu;
	BattlePotionInventory& mybattlepotioninventory;

	bool menuloop = true;



	MainMenu(InventorySystem& myinventorysystem, AlchemyWorkshop& myalchemyworkshop, Player* player, BattleSystem& mybattlesystem, ChangeMenu& mychangemenu, BattlePotionInventory& mybattlepotionsystem);
	

	void ShowMenu();

};
