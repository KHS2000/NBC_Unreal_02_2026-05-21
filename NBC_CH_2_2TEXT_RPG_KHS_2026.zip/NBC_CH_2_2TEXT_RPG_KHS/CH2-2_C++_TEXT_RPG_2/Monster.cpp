#include<iostream>
#include"Monster.h"
#include "Player.h"

using namespace std;

Monster::Monster(string name, int hp, int power, int defence, int expReward)
		:name(name), hp(hp), power(power), defence(defence), expReward(expReward){


	}

string Monster::getDropItem() {
	return "�Ϲݾ�����";
}

int Monster::getDropItemPrice() {
	return 10;
}

void Monster::monsterImage() {

}

Monster:: ~Monster() {}

void Monster::MonsterStaus() {
	cout << "\n\n=====================================\n   " <<
		name << " �� ���� �ɷ�ġ\n" <<
		"=====================================\n" <<
		"HP: " << /*HP*/hp <<
		"\n���ݷ�: " << /*Attack*/power << "    ����: " <</*Defence*/defence <<
		"\n=====================================\n";
}

int Monster::AttackDamage(Player& player)
{
	int Damage = 0;
	Damage = power - player.getDefence();

	if (Damage <= 0)
	{
		Damage = 1;
	}

	return Damage;
}


string Monster::GetName() {
		return name;
	}
int Monster::GetHp() {
	return hp;
}
int Monster::GetPower() {
	return power;
}
int Monster::GetDefence() {
	return defence;
}
int Monster::GetExpReward()
{
	return expReward;
}

void Monster::SetName(string name) {
		this->name = name;
	}
void Monster::SetHp(int hp) {
		this->hp = hp;
	}
void Monster::SetPower(int power) {
		this->power = power;
	}
void Monster::SetDefence(int defence) {
		this->defence = defence;
	}
void Monster::SetExpReward(int expReward)
{
	this->expReward = expReward;
}