#pragma once
#include <string>
#include"Player.h"

class Player;

class Monster {
protected:
	std::string name;
	int hp;
	int power;
	int defence;
	std::string dropItemName;
	int expReward;

public:

	virtual std::string getDropItem();

	virtual int getDropItemPrice();

	virtual void monsterImage();

	Monster(std::string name, int hp, int power, int defence, int expReward);
		
	void MonsterStaus();

	int AttackDamage(Player& player);

	virtual void attack() = 0;
	
	virtual ~Monster();

	std::string GetName();
	int GetHp();
	int GetPower();
	int GetDefence();
	int GetExpReward();

	void SetName(std::string name);
	void SetHp(int hp);
	void SetPower(int power);
	void SetDefence(int defence);
	void SetExpReward(int expReward);
};