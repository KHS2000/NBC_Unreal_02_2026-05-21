#include "Normal.h"
#include <iostream>

using namespace std;

Normal::Normal(string name, int hp, int mp, int power, int defence)
	: Player(name, hp, mp, power, defence)
	{
		job = "Normal";
	}

int Normal::AttackDamage(Monster* &monster)
	{
	int damage = 1;
		cout << name << "�⺻ �����մϴ�\n";
		return damage;
	}

void Normal::Attack(Monster*& monster)
{

}