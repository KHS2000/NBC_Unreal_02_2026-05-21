#pragma once
#include<string>
#include "Player.h"

class Normal :public Player {
public:
	Normal(std::string name, int hp, int mp, int power, int defence);


	int AttackDamage(Monster* &monster) override;

	void Attack(Monster*& monster)override;

};