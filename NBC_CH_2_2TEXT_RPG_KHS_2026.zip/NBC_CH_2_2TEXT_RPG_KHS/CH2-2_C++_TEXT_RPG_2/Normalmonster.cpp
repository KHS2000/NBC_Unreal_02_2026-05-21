#include<iostream>
#include"Normalmonster.h"

using namespace std;

NormalMonster::NormalMonster(string name, int hp, int power, int defence, int expReward)
    :Monster(name, hp, power, defence, expReward)
	{
    slimeitem = "�������� ������ ����";

	}

string NormalMonster::getDropItem() {
	return slimeitem;
}

int NormalMonster::getDropItemPrice() {
	return 30;
}

void NormalMonster::attack() {

    cout << "�����ġ��!";

}

void NormalMonster::monsterImage() {

    cout << "      *****      " << endl;
    cout << "    **     **    " << endl;
    cout << "   *  O   O  *   " << endl;
    cout << "   *    v    *   " << endl;
    cout << "    *********    " << endl;
}