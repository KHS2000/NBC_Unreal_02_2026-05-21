#pragma once
#include<string>
#include"Monster.h"

class NormalMonster :public Monster {
public:
	std::string slimeitem;

	NormalMonster(std::string name, int hp, int power, int defence, int expReward);

	void attack() override;

	int expReward;

	std::string getDropItem()override;

	int getDropItemPrice()override;

	void monsterImage()override;
	
};