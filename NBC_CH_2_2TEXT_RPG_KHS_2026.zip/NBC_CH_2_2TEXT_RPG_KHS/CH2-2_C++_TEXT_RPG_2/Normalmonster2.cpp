#include<iostream>
#include"Normalmonster2.h"

using namespace std;

NormalMonster2::NormalMonster2(string name, int hp, int power, int defence, int expReward)
	:Monster(name, hp, power, defence, expReward)
{
	Mushroomitem = "������ ��";

}



string NormalMonster2::getDropItem() {
	return Mushroomitem;
}

int NormalMonster2::getDropItemPrice() {
	return 50;
}

void NormalMonster2::attack() {

	cout << "�� �Ѹ���!";

}
void NormalMonster2::monsterImage() {

	cout << "      *****      " << endl;
	cout << "    **     **    " << endl;
	cout << "   *  O   O  *   " << endl;
	cout << "   *-------- *   " << endl;
	cout << "      *   *   " << endl;
	cout << "    *********    " << endl;
}