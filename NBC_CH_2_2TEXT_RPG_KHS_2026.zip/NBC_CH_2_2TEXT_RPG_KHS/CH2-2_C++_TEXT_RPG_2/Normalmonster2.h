#pragma once
#include<string>
#include"Monster.h"

class NormalMonster2 :public Monster {
public:
	std::string Mushroomitem;

	NormalMonster2(std::string name, int hp, int power, int defence, int expReward);

	void attack() override;

	std::string getDropItem()override;

	int expReward;

	int getDropItemPrice()override;

	void monsterImage()override;



};