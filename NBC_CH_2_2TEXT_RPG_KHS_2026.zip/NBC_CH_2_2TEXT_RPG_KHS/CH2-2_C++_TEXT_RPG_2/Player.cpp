#include "Player.h"
#include <iostream>
#include"Monster.h"

using namespace std;

Player::Player(string name, int hp, int mp, int power, int defence)
{
	this->name = name;
	this->hp = hp;
	this->mp = mp;
	this->power = power;
	this->defence = defence;

	level = 1;
	exp = 0;
	maxExp = 100;
	job = "None";
	uphp = 20;
	upmp = 10;
	uppower = 10;
	maxhp = 200;
	maxmp = 200;

	
}

void Player::LevelUp(Player* player,int maxhp)
{
	while (exp >= maxExp)
	{
		cout << "������! LV." << level<<" ";
		exp -= maxExp;
		level++;
		hp += 20;
		mp += 20;
		power += 10;
		cout << "->" << "LV." << level<<"\n";
		cout << "HP +" << uphp << ", MP +" << upmp << ", ���ݷ�+ " << uppower << "����!\n\n";
	}
	MaxHpCheck(player, maxhp);
}

//void Player::printStatus()//�÷��̾��� ���� �ɷ�ġ ���
//{

//	cout << "=====================================\n   " <<
//		/*����*/name << " �� ���� �ɷ�ġ\n" <<
//		"=====================================\n" <<
//		"HP: " << /*HP*/hp << "   MP: " <</*MP*/mp <<
//		"\n���ݷ�: " << /*Attack*/power << "   ����: " <</*Defence*/defence <<
//		"\n=====================================\n";
//}

void Player::printPlayerStatus() 
{
	cout << "=================================================\n";
	cout << "=                �÷��̾� �ɷ�ġ                =\n";
	cout << "=================================================\n" <<
		"=     �г���: " << name << " | " << "����: " << job << " | " << "Lv." << level << "      =\n" <<
		"-------------------------------------------------\n" <<
		"=  HP: " << hp << " | " << "MP: " << mp << " | " << "���ݷ�: " << power << " | " << "����: " << defence << "  =\n";
	cout << "=             ���� ����ġ: "<<exp<<"/"<<maxExp<<"               =\n";
		cout <<"-------------------------------------------------\n";
		cout<< "=================================================\n\n\n";
}

//int player::attackdamage(monster* monster)
//{
//	int damage=0;
//	damage = power - monster->getdefence();
//
//	if (damage <= 0)
//	{
//		damage = 1;
//	}
//
//	return damage;
//
//}

void Player::MaxHpCheck(Player* player, int hp)
{
	if (hp < player->getHP()) 
	{
		cout << "�ִ� HP�� " << getMaxhp() << " �Դϴ�.\n" <<
		"HP�� " << getMaxhp() << " �� �����մϴ�.\n";
		player->setHP(player->getMaxhp());
	}
	else if (hp == player->getHP())
	{
		cout << "���� �ִ� HP�Դϴ�!\n";
		cout << "���� HP " << player->getMaxhp()<<"\n\n";
		player->setHP(player->getMaxhp());
	}
	
}



Player::~Player() {}

string Player::getName()
{
	return name;
}
string Player::getJob()
{
	return job;
}
int Player::getHP()
{
	return hp;
}
int Player::getMP()
{
	return mp;
}
int Player::getPower()
{
	return power;
}
int Player::getDefence()
{
	return defence;
}
int Player::getLevel()
{
	return level;
}
int Player::getMaxhp()
{
	return maxhp;
}
int Player::getMaxmp()
{
	return maxmp;
}

void Player::setName(string name)
{
	this->name = name;
}
void Player::setJob(string job)
{
	this->job = job;
}
void Player::setHP(int hp)
{
	this->hp = hp;
}
void Player::setMP(int mp)
{
	this->mp = mp;
}
void Player::setPower(int power)
{
	this->power = power;
}
void Player::setDefence(int defence)
{
	this->defence = defence;
}
void Player::setLevel(int level)
{
	this->level = level;
}
void Player::setMaxhp(int maxhp)
{
	this->maxhp = maxhp;
}
void Player::setMaxmp(int maxhp)
{
	this->maxmp = maxmp;
}