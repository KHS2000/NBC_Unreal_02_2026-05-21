#pragma once
#include<string>
#include"Monster.h"

class Monster;

class Player      
{
protected:				
	std::string name;
	std::string job;
	int hp;
	int mp;
	int power;
	int defence;

public:
	Player(std::string name, int hp, int mp, int power, int defence);

	//void printStatus();

	void printPlayerStatus();

	void LevelUp(Player* player, int maxhp);

	void MaxHpCheck(Player* player, int hp);

	virtual int AttackDamage(Monster* &monster)=0;

	virtual void Attack(Monster* &monster) = 0;

	virtual ~Player();

	//virtual void attack(Monster& monster) = 0;

	int exp;
	int maxExp;
	int level;
	int uphp;
	int upmp;
	int uppower;
	int maxhp;
	int maxmp;


	std::string getName();
	std::string getJob();
	int getHP();
	int getMP();
	int getPower();
	int getDefence();
	int getLevel();
	int getMaxhp();
	int getMaxmp();

	void setName(std::string name);
	void setJob(std::string job);
	void setHP(int hp);
	void setMP(int mp);
	void setPower(int power);
	void setDefence(int defence);
	void setLevel(int level);
	void setMaxhp(int maxhp);
	void setMaxmp(int maxmp);







};