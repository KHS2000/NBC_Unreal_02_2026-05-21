#include<iostream>
#include "PotionRecipe.h"

using namespace std;

PotionRecipe::PotionRecipe(std::string name, std::string ingredient, std::string ingredient2) {
	this->name = name;
	this->ingredient = ingredient;
	this->ingredient2 = ingredient2;
}