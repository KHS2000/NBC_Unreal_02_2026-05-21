#pragma once
#include <string>

class PotionRecipe
{
public:
	std::string name;
	std::string ingredient;
	std::string ingredient2;

	PotionRecipe(std::string name, std::string ingredient, std::string ingredient2);
};
