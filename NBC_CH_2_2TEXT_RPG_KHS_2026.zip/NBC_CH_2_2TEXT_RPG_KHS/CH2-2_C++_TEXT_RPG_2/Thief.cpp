#include<iostream>
#include "Thief.h"

using namespace std;

Thief::Thief(string name, int hp, int mp, int power, int defence)
		: Player(name, hp, mp, power, defence)
	{
		this->power += 30;
		job = "����";
	}

int Thief::AttackDamage(Monster* &monster)
	{
	int Damage = 0;
	Damage = (power - monster->GetDefence()) / 5;

	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;

	int Thiefdamage = Damage * 5;



	return Damage;
	}


void Thief::Attack(Monster*& monster)
{
	int monstercurrentHP;
	monstercurrentHP = monster->GetHp();//�� ü��
	int Damage = 0;
	Damage = (power - monster->GetDefence()) / 5;

	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;

	int Thiefdamage = Damage * 5;

	cout << "-------- �÷��̾� �� --------\n";

	cout << "[" << job << "] " << "�ܰ����� ���!\n ";
	cout<< monster->GetName() << "���� " << damage << "������! (x5)\n";
	monster->SetHp(monster->GetHp() - Thiefdamage);
	cout << "������HP: " << monstercurrentHP << " -> " << monster->GetHp();
}