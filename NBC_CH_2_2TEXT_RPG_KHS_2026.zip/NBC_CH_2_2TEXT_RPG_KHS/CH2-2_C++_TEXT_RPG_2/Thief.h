#pragma once
#include<string>
#include "Player.h"

class Thief :public Player
{
public:
	Thief(std::string name, int hp, int mp, int power, int defence);

	int damage;


	int AttackDamage(Monster* &monster) override;

	void Attack(Monster*& monster) override;

};
