#include<iostream>
#include "Warrior.h"
using namespace std;

Warrior::Warrior(string name, int hp, int mp, int power, int defence)
		: Player(name, hp, mp, power, defence)
	{
		job = "����";
		this->hp += 30;
		damage = 0;
	}

int Warrior::AttackDamage(Monster* &monster)
	{
	int Damage = 0;
	Damage = power - monster->GetDefence();


	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;


	return Damage;
	}

void Warrior::Attack(Monster*& monster)
{
	int monstercurrentHP;
	monstercurrentHP = monster->GetHp();//�� ü��
	int Damage = 0;
	Damage = power - monster->GetDefence();


	if (Damage <= 0)
	{
		Damage = 1;
	}

	this->damage = Damage;
	cout << "-------- �÷��̾� �� --------\n";

	cout << "[" << job << "] " << "����� �ֵθ���!\n";
	cout<< monster->GetName() << "���� " << damage << "������!\n";
	monster->SetHp(monster->GetHp() - damage);
	cout << "������HP: " << monstercurrentHP << " -> " << monster->GetHp();
}