#pragma once
#include "Player.h"
#include <string>

class Warrior :public Player
{
public:
	Warrior(std::string name, int hp, int mp, int power, int defence);

	int damage;

	int AttackDamage(Monster* &monster) override;


	void Attack(Monster*& monster) override;
};